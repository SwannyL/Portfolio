'use strict';

//create global vars here


//preload data if needed
function preload() {


}

function setup() {
    createCanvas(600, 600);

}

function draw() {


}


function mousePressed() {

}



